# -*- coding: utf-8 -*-
from requests import get
from resources.lib.modules import control
import sys,re,json,urllib,urlparse

class movies:
	def __init__(self):
		self.list = []

	def search(self):
		try:
			control.idle()

			t = control.lang(32010).encode('utf-8')
			k = control.keyboard('', t) ; k.doModal()
			q = k.getText() if k.isConfirmed() else None

			if (q == None or q == ''): return

			headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': 'Bearer '+control.addon().getSetting('token')}
			response = get(control.myaddon_link+'info/movie/search/%s'%q, headers=headers)
			data = json.loads(response.text)
			if "data" not in data:
				print "### ERROR Load Movies Category JSON: {0}".format(category_id)
				return
			self.moviesItems(data['data'])
		except:
			return

	def moviesItems(self, movies):
		for movie in movies:
			meta = movie["meta"]

			try:
				imdb = movie['imdb_id']
				userLang = control.apiLanguage(control.lang)["id"]
				
				if userLang!="en":
					langData = control.getLangMeta("movie", imdb, 0, userLang)
					title = langData[0]['title']
					plot = langData[0]['overview']

				else:
					title = movie['title']

					if 'plot' in meta:
						plot = meta['plot']
					else:
						plot = 0
				
				title = title.encode('utf-8')
				plot = plot.encode('utf-8')

				year = movie['year']
				
				tmdb = movie['tmdb_id']
				if tmdb == None or tmdb == '' or tmdb == 'N/A': tmdb = '0'

				if 'poster' in meta:
					poster = meta['poster']
				else:
					poster = 0

				if 'fanart' in meta:
					fanart = meta['fanart']
				else:
					fanart = 0

				if 'released' in meta:
					premiered = meta['released'][0:10]
				else:
					premiered = '0'
				
				if 'genres' in meta:
					genre = meta['genres']
				else:
					genre = 0
				genre = genre.encode('utf-8')
			
				if 'runtime' in meta:
					duration = meta['runtime']
				else:
					duration = 0
				
				if 'rank' in meta:
					rating = meta['rank']
				else:
					rating = 0

				if 'votes' in meta:
					votes = meta['votes']
				else:
					votes = 0

				if 'director' in meta:
					director = meta['director']
				else:
					director = 0
				director = director.replace(', ', ' / ')
				director = director.encode('utf-8')
				
				if 'writer' in meta:
					writer = meta['writer']
				else:
					writer = 0
				writer = writer.replace(', ', ' / ')
				writer = writer.encode('utf-8')
				
				self.list.append({'imdb': imdb,'title': title, 'year': year, 'code': imdb, 'tmdb': tmdb, 'poster': poster, 'banner': '', 'fanart': fanart, 'premiered': premiered, 'studio': '', 'genre': genre, 'duration': duration, 'rating': rating, 'votes': votes, 'director': director, 'writer': writer, 'plot': plot})
			except: 
				print "####### ERROR JSON Rec: {0}".format(movie)
				pass
			
		self.movieDirectory(self.list)
		return self.list
	
			
	def moviesCategory(self, category_id):
		try:
			headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': 'Bearer '+control.addon().getSetting('token')}
			response = get(control.myaddon_link+'info/movies/categories/%s'%category_id, headers=headers)
			data = json.loads(response.text)
			if "data" not in data:
				print "### ERROR Load Movies Category JSON: {0}".format(category_id)
				return
			
			self.moviesItems(data['data'][0]["infos"])
		except:
			return []
			pass

	def movieDirectory(self, items):
		if items == None or len(items) == 0: control.idle() ; sys.exit()

		sysaddon = sys.argv[0]
		syshandle = int(sys.argv[1])
		addonPoster, addonBanner = control.addonPoster(), control.addonBanner()
		addonFanart, settingFanart = control.addonFanart(), control.setting('fanart')
		
		imdbs = ""
		for i in items:
			if i==0:
				imdbs = i['imdb']
			else:
				imdbs = imdbs+","+i['imdb']
			
		headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': 'Bearer '+control.addon().getSetting('token')}
		response = get(control.myaddon_link+'history/%s/'%(imdbs), headers=headers)
		hisotryJson = json.loads(response.text)
		historyArray = {}

		if "data" in hisotryJson:
			for h in hisotryJson["data"]:
				if "seconds" in h["data"] and h["data"]["seconds"]>0:
					historyArray[h["imdb_id"]] = h["data"]["seconds"]
				if "watched" in h["data"] and h["data"]["watched"]==True:
					historyArray[h["imdb_id"]] = 999999

		for i in items:
			try:
				label = '%s (%s)' % (i['title'], i['year'])
				imdb, title, year = i['imdb'], i['title'], i['year']
				sysname = urllib.quote_plus('%s (%s)' % (title, year))
				systitle = urllib.quote_plus(title)
				meta = dict((k,v) for k, v in i.iteritems() if not v == '0')
				meta.update({'mediatype': 'movie'})

				if not 'duration' in i: meta.update({'duration': '120'})
				elif i['duration'] == '0': meta.update({'duration': '120'})
				try: meta.update({'duration': str(int(meta['duration']) * 60)})
				except: pass
				try: meta.update({'genre': cleangenre.lang(meta['genre'], self.lang)})
				except: pass
				
				if 'poster' in i and not i['poster'] == '0':
					poster = i['poster']
				else:
					poster = 0
					
				sysmeta = urllib.quote_plus(json.dumps(meta))
				url = '%s?action=moviePlay&imdb=%s&title=%s&poster=%s' % (sysaddon, imdb, systitle,poster)
				sysurl = urllib.quote_plus(url)

				item = control.item(label=label)
				item.addStreamInfo('video', { 'width':1920 ,'height' : 1080 })
				
				if imdb in historyArray:
					if historyArray[imdb]==999999:
						meta.update({'playcount': 1})
					else:
						item.setProperty("resumetime", str(historyArray[imdb]))
						
				art = {}

				if 'poster' in i and not i['poster'] == '0':
					art.update({'icon': i['poster'], 'thumb': i['poster'], 'poster': i['poster']})
				else:
					art.update({'icon': addonPoster, 'thumb': addonPoster, 'poster': addonPoster})

				if 'banner' in i and not i['banner'] == '0':
					art.update({'banner': i['banner']})
				else:
					art.update({'banner': addonBanner})

				if 'clearlogo' in i and not i['clearlogo'] == '0':
					art.update({'clearlogo': i['clearlogo']})

				if 'clearart' in i and not i['clearart'] == '0':
					art.update({'clearart': i['clearart']})

				if settingFanart == 'true' and 'fanart' in i and not i['fanart'] == '0':
					item.setProperty('Fanart_Image', i['fanart'])
				elif not addonFanart == None:
					item.setProperty('Fanart_Image', addonFanart)

				del (meta["banner"]);del (meta["fanart"]);del (meta["imdb"]);del (meta["poster"]);del (meta["tmdb"]);
				
				cm = []
				#cm.append(("AAAA", 'RunPlugin(%s?action=moviePlaycount&imdb=%s&query=6)' % (sysaddon, imdb)))

				item.setArt(art)
				item.addContextMenuItems(cm)
				item.setInfo(type='Video', infoLabels = meta)

				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
			except:
				pass

		control.content(syshandle, 'movies')
		control.directory(syshandle, cacheToDisc=True)