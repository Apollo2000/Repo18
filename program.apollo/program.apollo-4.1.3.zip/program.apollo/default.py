# -*- coding: utf-8 -*-

import urlparse,sys

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))

action = params.get('action')
imdb = params.get('imdb')
title = params.get('title')
param = params.get('param')
season = params.get('season')
episode = params.get('episode')
poster = params.get('poster')
plot = params.get('plot')
resumeTime = params.get('resumeTime')
category_id = params.get('category_id')
epg_id = params.get('epg_id')

if action == None:
	from resources.lib.indexers import navigator
	navigator.navigator().root()

elif action == 'movieMyList':
	from resources.lib.modules import myaddon
	myaddon.myAddon().movieMyList(imdb,param)

elif action == 'tvMyList':
	from resources.lib.modules import myaddon
	myaddon.myAddon().tvMyList(imdb,param)

elif action == 'liveMyList':
	from resources.lib.modules import myaddon
	myaddon.myAddon().liveMyList(epg_id,param)

elif action == 'movieNav':
	from resources.lib.indexers import navigator
	navigator.navigator().movies()

elif action == 'moviesCategory':
	from resources.lib.indexers import movies
	movies.movies().moviesCategory(category_id)

elif action == 'moviesYear':
	from resources.lib.indexers import movies
	movies.movies().moviesYear(param)

elif action == 'moviesMyList':
	from resources.lib.indexers import movies
	movies.movies().moviesMyList()

elif action == 'moviesYears':
	from resources.lib.indexers import navigator
	navigator.navigator().moviesYears()

elif action == 'episodesDate':
	from resources.lib.indexers import navigator
	navigator.navigator().episodesDate()

elif action == 'tvshowsYears':
	from resources.lib.indexers import navigator
	navigator.navigator().tvshowsYears()

elif action == 'tvshowsYear':
	from resources.lib.indexers import tvshows
	tvshows.tvshows().tvshowsYear(param)

elif action == 'tvshowsMyList':
	from resources.lib.indexers import tvshows
	tvshows.tvshows().tvshowsMyList()

elif action == 'episodesDateList':
	from resources.lib.indexers import episodes
	episodes.episodes().episodesDateList(param)

elif action == 'episodesMyList':
	from resources.lib.indexers import episodes
	episodes.episodes().episodesMyList()

elif action == 'episodesList':
	from resources.lib.indexers import episodes
	episodes.episodes().episodesList()
	
elif action == 'tools':
	from resources.lib.modules import control
	control.openSettings(param)
	
elif action == 'moviePlay':
	from resources.lib.modules import myaddon
	myaddon.myAddon().moviePlay(imdb,title,poster,plot,resumeTime)

elif action == 'episodePlay':
	from resources.lib.modules import myaddon
	myaddon.myAddon().episodePlay(imdb,season,episode,title,poster,plot,resumeTime)
	
elif action == 'tvNav':
	from resources.lib.indexers import navigator
	navigator.navigator().tvshows()

elif action == 'tvshowsCategory':
	from resources.lib.indexers import tvshows
	tvshows.tvshows().tvshowsCategory(category_id)
	
elif action == 'tvshowsSeasons':
	from resources.lib.indexers import episodes
	episodes.seasons().seasonsCategory(imdb)

elif action == 'tvshowsEpisods':
	from resources.lib.indexers import episodes
	episodes.episodes().episodesCategory(imdb,season)
	
elif action == 'channelsNav':
	from resources.lib.indexers import navigator
	navigator.navigator().channels()
elif action == 'myListNav':
	from resources.lib.indexers import navigator
	navigator.navigator().myListNav()

elif action == 'channelsCategory':
	from resources.lib.indexers import channels
	channels.channels().channelsCategory(category_id)
elif action == 'channelsMyList':
	from resources.lib.indexers import channels
	channels.channels().channelsMyList()
	
elif action == 'searchNav':
	from resources.lib.indexers import navigator
	navigator.navigator().search()
elif action == 'movieSearch':
	from resources.lib.indexers import movies
	movies.movies().search()
elif action == 'tvSearch':
	from resources.lib.indexers import tvshows
	tvshows.tvshows().search()
elif action == 'channelSearch':
	from resources.lib.indexers import channels
	channels.channels().search()	
elif action == 'login':
	from resources.lib.modules import myaddon
	myaddon.myAddon().login(param)
elif action == 'logout':
	from resources.lib.modules import myaddon
	myaddon.myAddon().logout()
elif action == 'tvguide':
	from resources.lib.modules import myaddon
	myaddon.myAddon().tvguide()
elif action == 'clean':
	from resources.lib.modules import myaddon
	myaddon.myAddon().cleanCache()
elif action == 'buffer':
	from resources.lib.modules import myaddon
	myaddon.myAddon().setAdvanceBuffer()