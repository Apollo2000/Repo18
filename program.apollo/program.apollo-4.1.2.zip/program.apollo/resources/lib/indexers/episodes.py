# -*- coding: utf-8 -*-
from requests import get
from resources.lib.modules import control
import sys,re,json,urllib,urlparse
from datetime import datetime

class seasons:
	def __init__(self):
		self.list = []

	def seasonsCategory(self, imdb):
		try:
			headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'X-API-VERSION': 'v2', 'Authorization': 'Bearer '+control.addon().getSetting('token')}
			response = get(control.myaddon_link+'info/tvshows/%s'%imdb, headers=headers)
			data = json.loads(response.text)
			if "data" not in data:
				print "### ERROR Load TV Shows Info JSON: {0}".format(imdb)
				return
			
			tvshow = data["data"][0]
			meta = tvshow["meta"]

			userLang = control.apiLanguage(control.lang)["id"]

						
			if 'poster' in meta:
				poster = meta['poster']
			else:
				poster = 0

			if 'fanart' in meta:
				fanart = meta['fanart']
			else:
				fanart = 0
			seasons = []
			for season in tvshow["meta"]["seasons"]:
				self.list.append({'season': season,"imdb":imdb,"poster":poster,"fanart":fanart})
			
			self.tvshowSeasonDirectory(self.list)
			return self.list
		except:
			pass

	def tvshowSeasonDirectory(self, items):
		if items == None or len(items) == 0: control.idle() ; sys.exit()

		sysaddon = sys.argv[0]
		syshandle = int(sys.argv[1])
		addonPoster, addonBanner = control.addonPoster(), control.addonBanner()
		addonFanart, settingFanart = control.addonFanart(), control.setting('fanart')

		for i in items:
			try:
				label = "Season %s"%i['season']
				systitle = sysname = urllib.quote_plus(label)
				imdb = i['imdb']

				url = '%s?action=tvshowsEpisods&season=%s&imdb=%s&title=%s' % (sysaddon,i['season'], imdb, systitle)

				cm = []

				item = control.item(label=label)

				art = {}

				if 'poster' in i and not i['poster'] == '0':
					art.update({'icon': i['poster'], 'thumb': i['poster'], 'poster': i['poster']})
				else:
					art.update({'icon': addonPoster, 'thumb': addonPoster, 'poster': addonPoster})

				if 'banner' in i and not i['banner'] == '0':
					art.update({'banner': i['banner']})
				elif 'fanart' in i and not i['fanart'] == '0':
					art.update({'banner': i['fanart']})
				else:
					art.update({'banner': addonBanner})

				if 'clearlogo' in i and not i['clearlogo'] == '0':
					art.update({'clearlogo': i['clearlogo']})

				if 'clearart' in i and not i['clearart'] == '0':
					art.update({'clearart': i['clearart']})

				if settingFanart == 'true' and 'fanart' in i and not i['fanart'] == '0':
					item.setProperty('Fanart_Image', i['fanart'])
				elif not addonFanart == None:
					item.setProperty('Fanart_Image', addonFanart)
				

				item.setArt(art)

				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
			except:
				pass

		control.content(syshandle, 'tvshows')
		control.directory(syshandle, cacheToDisc=True)

class episodes:
	def __init__(self):
		self.list = []
		self.headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'X-API-VERSION': 'v2', 'Authorization': 'Bearer '+control.addon().getSetting('token')}
		
	def episodesCategory(self, imdb, season):
		try:
			response = get(control.myaddon_link+'info/tvshows/%s'%imdb, headers=self.headers)
			data = json.loads(response.text)
			if "data" not in data:
				print "### ERROR Load TV Shows Info JSON: {0}".format(imdb)
				return
			
			tvshow = data["data"][0]
			meta = tvshow["meta"]
			meta_episodes = tvshow["meta_episodes"]
			
			if 'fanart' in meta:
				fanart = meta['fanart']
			else:
				fanart = 0
			
			for seasonData in meta_episodes:
				if int(seasonData["seasonNumber"]) == int(season):
					break
			
			episodes = seasonData["episodes"]
			episodes.sort(key=lambda x: [x['episode']])
			for episode in episodes:
				try:
					if 'episode' in episode:
						title = "%d. "%episode["episode"]

					if 'title' in episode:
						title = title+episode['title']
					else:
						title = 0
					
					if 'plot' in episode and episode['plot']:
						plot = episode['plot']
					else:
						plot = ''

					if 'screenshot' in episode:
						poster = episode['screenshot']
					else:
						poster = meta['poster']

					if 'duration' in episode:
						duration = int(episode['duration'])
					else:
						duration = '0'

					if 'released' in episode:
						ts = int(episode['released'])
						premiered = datetime.utcfromtimestamp(ts).strftime('%Y-%m-%d')
					else:
						premiered = '0'
					
					title = title.encode('utf-8')
					plot = plot.encode('utf-8')					

					self.list.append({'title': title,"imdb":imdb,"poster":poster,"fanart":fanart,"premiered":premiered,"plot":plot,"duration":duration,"season":int(season),"episode":int(episode["episode"])})
				except: 
					print "####### ERROR JSON Rec: {0}".format(episode)
					pass
					
			self.tvshowSeasonDirectory(self.list)
			return self.list
		except:
			pass			

	def tvshowSeasonDirectory(self, items):
		if items == None or len(items) == 0: control.idle() ; sys.exit()
		
		sysaddon = sys.argv[0]
		syshandle = int(sys.argv[1])
		addonPoster, addonBanner = control.addonPoster(), control.addonBanner()
		addonFanart, settingFanart = control.addonFanart(), control.setting('fanart')
		
		imdb = items[0]['imdb']
		season = items[0]['season']
		
		response = get(control.myaddon_link+'history/%s/'%(imdb), headers=self.headers)
		hisotryJson = json.loads(response.text)
		historyArray = {}
		
		if "data" in hisotryJson:
			for h2 in hisotryJson["data"]:
				for h3 in h2["data"]:
					h = h2["data"][h3]
					if "seconds" in h and h["seconds"]>0 and season==h["season"]:
						historyArray[h["episode"]] = h["seconds"]
					if "watched" in h and h["watched"]==True and season==h["season"]:
						historyArray[h["episode"]] = 999999
		
		#control.dialog.ok("Z","%s"%historyArray)
		for i in items:
			try:
				label = i['title']
				systitle = sysname = urllib.quote_plus(i['title'])
				imdb = i['imdb']
				episode = i['episode']
				season = i['season']
				
				meta = dict((k,v) for k, v in i.iteritems() if not v == '0')
				meta.update({'mediatype': 'episode'})
				if not 'duration' in i: meta.update({'duration': '60'})
				else: meta.update({'duration': i['duration']})

				if 'poster' in i and not i['poster'] == '0':
					poster = i['poster']
				else:
					poster = 0
				
				url = '%s?action=episodePlay&imdb=%s&title=%s&season=%s&episode=%s&poster=poster' % (sysaddon, imdb, systitle, season, episode)

				cm = []

				item = control.item(label=label)
				
				art = {}

				if episode in historyArray:
					if historyArray[episode]==999999:
						meta.update({'playcount': 1})
					else:
						item.setProperty("resumetime", str(historyArray[episode]))

				if poster != '0':
					art.update({'icon': i['poster'], 'thumb': i['poster'], 'poster': i['poster']})
				else:
					art.update({'icon': addonPoster, 'thumb': addonPoster, 'poster': addonPoster})

				if 'banner' in i and not i['banner'] == '0':
					art.update({'banner': i['banner']})
				elif 'fanart' in i and not i['fanart'] == '0':
					art.update({'banner': i['fanart']})
				else:
					art.update({'banner': addonBanner})

				if 'clearlogo' in i and not i['clearlogo'] == '0':
					art.update({'clearlogo': i['clearlogo']})

				if 'clearart' in i and not i['clearart'] == '0':
					art.update({'clearart': i['clearart']})

				if settingFanart == 'true' and 'fanart' in i and not i['fanart'] == '0':
					item.setProperty('Fanart_Image', i['fanart'])
				elif not addonFanart == None:
					item.setProperty('Fanart_Image', addonFanart)

				del (meta["fanart"]);del (meta["imdb"]);del (meta["poster"]);
				item.setArt(art)
				item.addContextMenuItems(cm)
				item.setInfo(type='Video', infoLabels = meta)

				
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
			except:
				pass

		control.content(syshandle, 'tvshows')
		control.directory(syshandle, cacheToDisc=True)

	def episodesMyList(self):
		response = get(control.myaddon_link+'favorite/episodes/', headers=self.headers)
		favoriteJson = json.loads(response.text)
		
		if "data" in favoriteJson:
			if favoriteJson["data"] is not None:
				syshandle = int(sys.argv[1])
				sysaddon = sys.argv[0]
				historyArray = {}

				for i in favoriteJson["data"]:
					try:
						systitle = sysname = urllib.quote_plus(i['title'])
						imdb = i['imdb_id']
						episode = i['episode']
						season = i['season']
					
						label = i['title']+" S%s:E%s "%(season,episode)
						
						if imdb not in historyArray:
							historyArray[imdb] = {}
							response = get(control.myaddon_link+'history/%s/'%(imdb), headers=self.headers)
							hisotryJson = json.loads(response.text)
							
							if "data" in hisotryJson:
								for h2 in hisotryJson["data"]:
									for h3 in h2["data"]:
										h = h2["data"][h3]
										if "seconds" in h and h["seconds"]>0 and season==h["season"]:
											historyArray[imdb][h["episode"]] = h["seconds"]
										if "watched" in h and h["watched"]==True and season==h["season"]:
											historyArray[imdb][h["episode"]] = 999999
						
						
						meta = dict((k,v) for k, v in i["meta"].iteritems() if not v == '0')
						meta.update({'mediatype': 'episode'})
						if not 'duration' in i: meta.update({'duration': '60'})
						else: meta.update({'duration': i['duration']})
						
						url = '%s?action=episodePlay&imdb=%s&title=%s&season=%s&episode=%s' % (sysaddon, imdb, systitle, season, episode)

						cm = []

						item = control.item(label=label)
						
						art = {}

						if episode in historyArray:
							if historyArray[episode]==999999:
								meta.update({'playcount': 1})
							else:
								item.setProperty("resumetime", str(historyArray[episode]))

						if "meta" in i:
							if 'poster' in i["meta"] and not i["meta"]['poster'] == '0':
								poster = i["meta"]['poster']
								art.update({'icon': poster, 'thumb': poster, 'poster': poster})
							else:
								poster = 0
					
						item.setArt(art)
						item.setInfo(type='Video', infoLabels = meta)
						
						control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
					except:
						pass

				control.content(syshandle, 'tvshows')
				control.directory(syshandle, cacheToDisc=True)